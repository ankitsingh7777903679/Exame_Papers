﻿Imports System.Data.SqlClient
Public Class Form1
    Dim cn As New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Ankit Singh\Desktop\New folder\.net\employee\employee\employee.mdf;Integrated Security=True;User Instance=True")
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        cn.Open()
        loadData()
    End Sub

    Private Sub btninsert_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btninsert.Click
        Dim strsql As String
        Dim cmd As New SqlCommand

        Dim salary As Double = Val(txtsalary.Text)
        Dim incsalary As Double = salary + (salary * 10 / 100)

        strsql = "INSERT INTO emp VALUES(@pid,@pname,@dept,@desi,@salary)"

        cmd.CommandText = strsql
        cmd.Connection = cn

        cmd.Parameters.AddWithValue("@pid", Val(txteid.Text))
        cmd.Parameters.AddWithValue("@pname", txtename.Text)
        cmd.Parameters.AddWithValue("@dept", txtdpt.Text)
        cmd.Parameters.AddWithValue("@desi", txtdesi.Text)
        cmd.Parameters.AddWithValue("@salary", incsalary)

        cmd.ExecuteNonQuery()
        MsgBox("data inserted")
        loadData()


    End Sub

    Private Sub btnsearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsearch.Click
        Dim selectore As String = "SELECT * FROM emp where dept = @dept AND desi = @desi"
        Dim cmd As New SqlCommand(selectore, cn)
        cmd.Parameters.AddWithValue("@dept", txtdpt.Text)
        cmd.Parameters.AddWithValue("@desi", txtdesi.Text)

        Dim addetore As New SqlDataAdapter(cmd)
        Dim dt As New DataTable

        addetore.Fill(dt)
        DataGridView1.DataSource = dt
    End Sub

    Private Sub loadData()
        Dim selectore As String = "SELECT * FROM emp"
        Dim addetore As New SqlDataAdapter(selectore, cn)
        Dim dt As New DataTable

        addetore.Fill(dt)
        DataGridView1.DataSource = dt
    End Sub

    Private Sub btndisnoemp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndisnoemp.Click
        Dim selectore As String = "SELECT dept, COUNT(*) AS total_emp FROM emp GROUP BY dept"
        Dim cmd As New SqlCommand(selectore, cn)
        cmd.Parameters.AddWithValue("@dept", txtdpt.Text)

        Dim addetore As New SqlDataAdapter(cmd)
        Dim dt As New DataTable

        addetore.Fill(dt)
        DataGridView1.DataSource = dt
    End Sub
End Class
