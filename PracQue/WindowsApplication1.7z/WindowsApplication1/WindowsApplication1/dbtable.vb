﻿Imports System.Data
Imports System.Data.SqlClient

Public Class dbtable
    Dim cn As New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Admin\OneDrive\Desktop\winappsybca4\winappsybca4\Database1.mdf;Integrated Security=True;User Instance=True")

    Private Sub dbtable_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        cn.Open()
        LoadData()
    End Sub

    Private Sub btnins_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnins.Click
        Dim strSql As String
        Dim cmd As New SqlCommand

        strSql = "insert into EMP values(@ENO,@ENAME,@EMOBILE,@ESALARY)"

        cmd.CommandText = strSql
        cmd.Connection = cn

        cmd.Parameters.AddWithValue("@ENO", Val(txtno.Text))
        cmd.Parameters.AddWithValue("@ENAME", txtname.Text)
        cmd.Parameters.AddWithValue("@EMOBILE", Val(txtmob.Text))
        cmd.Parameters.AddWithValue("@ESALARY", Val(txtsalary.Text))

        cmd.ExecuteNonQuery()
        MsgBox("RECORD INSERTED SUCCESSFULLY")
        cmd.Dispose()
        ClearData()
        LoadData()
    End Sub

    Private Sub btnupdate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnupdate.Click
        Dim strSql As String
        Dim cmd As New SqlCommand

        strSql = "update EMP set ENAME=@ENAME,EMOBILE=@EMOBILE,ESALARY=@ESALARY where ENO=@ENO"

        cmd.CommandText = strSql
        cmd.Connection = cn

        cmd.Parameters.AddWithValue("@ENO", Val(txtno.Text))
        cmd.Parameters.AddWithValue("@ENAME", txtname.Text)
        cmd.Parameters.AddWithValue("@EMOBILE", Val(txtmob.Text))
        cmd.Parameters.AddWithValue("@ESALARY", Val(txtsalary.Text))

        cmd.ExecuteNonQuery()
        MsgBox("RECORD UPDATED SUCCESSFULLY")
        cmd.Dispose()
        ClearData()
        LoadData()
    End Sub

    Private Sub btndel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btndel.Click
        If MsgBox("DO YOU WANT TO DELETE DATA", vbYesNo + vbDefaultButton2 + vbQuestion) = vbYes Then
            Dim strSql As String
            Dim cmd As New SqlCommand

            strSql = "delete from EMP where ENO=@ENO"

            cmd.CommandText = strSql
            cmd.Connection = cn

            cmd.Parameters.AddWithValue("@ENO", Val(txtno.Text))


            cmd.ExecuteNonQuery()
            MsgBox("RECORD DELETED SUCCESSFULLY")
            cmd.Dispose()
            ClearData()
            LoadData()
        End If
    End Sub

    Private Sub ClearData()
        txtno.Clear()
        txtname.Clear()
        txtmob.Clear()
        txtsalary.Clear()
    End Sub

    Private Sub LoadData()
        Dim selector As String = "select * from EMP"
        Dim adaptor As New SqlDataAdapter(selector, cn)
        Dim dt As New DataTable

        adaptor.Fill(dt)
        DataGridView1.DataSource = dt
    End Sub

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub
End Class