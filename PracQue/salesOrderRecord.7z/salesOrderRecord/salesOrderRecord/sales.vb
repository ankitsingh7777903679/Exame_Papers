﻿Imports System.Data.SqlClient
Public Class sales
    Dim cn As New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Ankit Singh\AppData\Local\Temporary Projects\salesOrderRecord\sales_order.mdf;Integrated Security=True;User Instance=True")
    Private Sub sales_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        cn.Open()
        loadData()
    End Sub

    Private Sub btninsert_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btninsert.Click
        Dim strsql As String
        Dim cmd As New SqlCommand

        strsql = "INSERT INTO sales_order VALUES(@order_no, @order_date, @client_name, @dely_address, @dely_boy_name, @dely_date, @order_status)"

        cmd.CommandText = strsql
        cmd.Connection = cn

        cmd.Parameters.AddWithValue("@order_no", Val(txto_no.Text))
        cmd.Parameters.AddWithValue("@order_date", DateTime.Parse(txto_date.Text))
        cmd.Parameters.AddWithValue("@client_name", txto_name.Text)
        cmd.Parameters.AddWithValue("@dely_address", txtd_address.Text)
        cmd.Parameters.AddWithValue("@dely_boy_name", txtd_boy_name.Text)
        cmd.Parameters.AddWithValue("@dely_date", DateTime.Parse(txtd_date.Text))
        cmd.Parameters.AddWithValue("@order_status", txto_status.Text)

        cmd.ExecuteNonQuery()
        MsgBox("data inserted")
        loadData()

    End Sub

    Private Sub loadData()
        Dim selector As String = "select * from sales_order ORDER BY client_name DESC"
        Dim addetor As New SqlDataAdapter(selector, cn)
        Dim dt As New DataTable

        addetor.Fill(dt)
        DataGridView1.DataSource = dt
    End Sub

    Private Sub btnupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupdate.Click
        Dim strsql As String
        Dim cmd As New SqlCommand

        strsql = "UPDATE sales_order SET order_date = @order_date, client_name = @client_name,dely_address = @dely_address,dely_boy_name = @dely_boy_name,dely_date = @dely_date,order_status = @order_status WHERE order_no = @order_no"

        cmd.CommandText = strsql
        cmd.Connection = cn

        cmd.Parameters.AddWithValue("@order_no", Val(txto_no.Text))
        cmd.Parameters.AddWithValue("@order_date", DateTime.Parse(txto_date.Text))
        cmd.Parameters.AddWithValue("@client_name", txto_name.Text)
        cmd.Parameters.AddWithValue("@dely_address", txtd_address.Text)
        cmd.Parameters.AddWithValue("@dely_boy_name", txtd_boy_name.Text)
        cmd.Parameters.AddWithValue("@dely_date", DateTime.Parse(txtd_date.Text))
        cmd.Parameters.AddWithValue("@order_status", txto_status.Text)

        cmd.ExecuteNonQuery()
        MsgBox("Update data ")
        loadData()
    End Sub

    Private Sub btndelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndelete.Click
        Dim strsql As String
        Dim cmd As New SqlCommand

        strsql = "delete from sales_order where order_no = @order_no"

        cmd.CommandText = strsql
        cmd.Connection = cn

        cmd.Parameters.AddWithValue("@order_no", Val(txto_no.Text))
       

        cmd.ExecuteNonQuery()
        MsgBox("delete data ")
        loadData()
    End Sub

    Private Sub btnsearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsearch.Click
        Dim selector As String = "select * from sales_order WHERE dely_boy_name = @dely_boy_name"

        Dim cmd As New SqlCommand(selector, cn)
        cmd.Parameters.AddWithValue("@dely_boy_name", txtd_boy_name.Text)

        Dim addetor As New SqlDataAdapter(cmd)
        Dim dt As New DataTable

        addetor.Fill(dt)
        DataGridView1.DataSource = dt
    End Sub
End Class