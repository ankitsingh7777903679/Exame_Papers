﻿Imports System.Data.SqlClient
Public Class product
    Dim cn As New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Ankit Singh\Desktop\New folder\.net\product1\product1\product.mdf;Integrated Security=True;User Instance=True")
    Private Sub product_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        cn.Open()
        loadData()
    End Sub

    Private Sub btninsert_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btninsert.Click
        Dim strsql As String
        Dim cmd As New SqlCommand

        Dim salary As Double = Val(txtprice.Text)
        Dim incsalary As Double = salary + (salary * 5 / 100)

        strsql = "INSERT INTO product VALUES(@pno,@pname,@price,@qnt,@exdate)"

        cmd.CommandText = strsql
        cmd.Connection = cn

        cmd.Parameters.AddWithValue("@pno", Val(txtpno.Text))
        cmd.Parameters.AddWithValue("@pname", txtpname.Text)
        cmd.Parameters.AddWithValue("@price", incsalary)
        cmd.Parameters.AddWithValue("@qnt", Val(txtqnt.Text))
        cmd.Parameters.AddWithValue("@exdate", DateTime.Parse(txtexdate.Text))

        cmd.ExecuteNonQuery()
        MsgBox("Data Inserted")
        loadData()

    End Sub


    Private Sub loadData()
        Dim selector As String = "SELECT * FROM product"
        Dim addetor As New SqlDataAdapter(selector, cn)
        Dim dt As New DataTable

        addetor.Fill(dt)
        DataGridView1.DataSource = dt

    End Sub

    Private Sub btnsearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsearch.Click
        Dim selector As String = "SELECT * FROM product WHERE pname = @pname"
        Dim cmd As New SqlCommand(selector, cn)
        cmd.Parameters.AddWithValue("@pname", txtpname.Text)

        Dim addetor As New SqlDataAdapter(cmd)
        Dim dt As New DataTable

        addetor.Fill(dt)
        DataGridView1.DataSource = dt
    End Sub

    Private Sub btnexdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnexdate.Click
        Dim strsql As String
        Dim cmd As New SqlCommand

        strsql = "UPDATE product SET exdate = NULL"

        cmd.CommandText = strsql
        cmd.Connection = cn

        cmd.ExecuteNonQuery()
        MsgBox("ExDATE DELETE")
        loadData()
    End Sub
End Class